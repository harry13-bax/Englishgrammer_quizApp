package com.ultimate.englishgrammarquiz;

/**
 * Created by Legandan on 27/02/2021.
 */

public class Constant {

	// Change number of clicks for display interstitial

	public static int adShow = 3; // clicks for list items
	public static int adShowQ = 11; // quiz activity
	public static int adCount = 0;


}
